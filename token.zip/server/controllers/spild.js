var request = require('request');
const fs = require("fs")
const querystring = require('querystring');

class SpildController {
  static async getSpild(ctx) {
    let res = await new Promise((resolve, reject) => {
      try {
        request("http://119.29.90.79:8081/getAll", function (err, res, body) {
          if (err) {
            resolve(null)
          } else {
            resolve(body)
          }
        })
      } catch (error) {
        resolve(null)
      }
      setTimeout(function () {
        reject(null)
      }, 10000)
    })
    // let res = fs.readFileSync("./1.txt")
    if (res !== null) {
      let _res = JSON.parse(res)
      if (_res.code != 0) {
        return ctx.success({
          msg: _res.msg,
          success: false
        })
      } else {
        return ctx.success({
          msg: '数据获取成功',
          data: _res.data,
          success: true
        });
      }
    } else {
      return ctx.success({
        msg: '数据获取失败!',
        success: false
      })
    }

  }
  //通过ip 和name 获取详细信息
  static async getDetail(ctx) {
    let req =querystring.stringify(ctx.query)
    let res = await new Promise((resolve, reject) => {
      try {
        request("http://119.29.90.79:8081/moreInformation?"+req, function (err, res, body) {
          if (err) {
            resolve(null)
          } else {
            resolve(body)
          }
        })
      } catch (error) {
        resolve(null)
      }
      setTimeout(function () {
        reject(null)
      }, 10000)
    })

    if (res !== null) {
      let _res = JSON.parse(res)
      if (_res.code != 0) {
        return ctx.success({
          msg: _res.msg,
          success: false
        })
      } else {
        return ctx.success({
          msg: '数据获取成功',
          data: JSON.parse(_res.data),
          success: true
        });
      }
    } else {
      return ctx.success({
        msg: '数据获取失败!',
        success: false
      })
    }

  }
}
exports = module.exports = SpildController;